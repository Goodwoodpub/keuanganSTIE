'use strict';
/*
 * Sistem Manajemen Dana Operasional STIE Krakatau — server.
 * Express + PostgreSQL (Railway) dengan sesi login di sisi server.
 */
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const createStore = require('./src/store');

const PORT = +process.env.PORT || 3000;
const PROD = process.env.NODE_ENV === 'production';
const SECRET = process.env.SESSION_SECRET || (() => {
  if (PROD) console.warn('[PERINGATAN] SESSION_SECRET belum diatur. Sesi login akan hilang setiap kali server restart.');
  return crypto.randomBytes(32).toString('hex');
})();
const SESSION_DAYS = +process.env.SESSION_DAYS || 7;
const ROLES = ['Bendahara', 'Admin'];
const MIME = {
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'application/pdf': 'pdf',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/vnd.ms-excel': 'xls', 'text/csv': 'csv',
};
const MAX_FILE = 4 * 1024 * 1024;

const store = createStore();
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

/* ---------- Utilitas ---------- */
const hashPw = pw => new Promise((ok, no) => {
  const salt = crypto.randomBytes(16);
  crypto.scrypt(pw, salt, 64, (e, k) => e ? no(e) : ok('scrypt$' + salt.toString('hex') + '$' + k.toString('hex')));
});
const checkPw = (pw, stored) => new Promise(ok => {
  const [alg, s, h] = String(stored).split('$');
  if (alg !== 'scrypt' || !s || !h) return ok(false);
  crypto.scrypt(pw, Buffer.from(s, 'hex'), 64, (e, k) => {
    if (e) return ok(false);
    const H = Buffer.from(h, 'hex');
    ok(H.length === k.length && crypto.timingSafeEqual(H, k));
  });
});
const b64u = b => Buffer.from(b).toString('base64url');
const sign = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
const makeToken = u => { const p = b64u(JSON.stringify({ u: u.u, pv: u.pv || 1, exp: Date.now() + SESSION_DAYS * 864e5 })); return p + '.' + sign(p); };
const readToken = t => {
  const [p, s] = String(t || '').split('.');
  if (!p || !s) return null;
  const a = Buffer.from(sign(p)), b = Buffer.from(s);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try { const d = JSON.parse(Buffer.from(p, 'base64url').toString()); return d.exp > Date.now() ? d : null; } catch (e) { return null; }
};
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(/;\s*/).filter(Boolean).map(c => {
  const i = c.indexOf('='); return [c.slice(0, i), decodeURIComponent(c.slice(i + 1))];
}));
const setSid = (req, res, v, maxAge) => res.append('Set-Cookie',
  `sid=${v}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${req.secure ? '; Secure' : ''}`);
const pub = u => ({ u: u.u, name: u.name, role: u.role });
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const validUser = s => /^[a-z0-9._-]{3,32}$/.test(s);

/* ---------- Header keamanan ---------- */
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
    'Referrer-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  });
  if (req.secure) res.set('Strict-Transport-Security', 'max-age=15552000');
  next();
});

/* ---------- Auth middleware ---------- */
const auth = wrap(async (req, res, next) => {
  const t = readToken(cookies(req).sid);
  const u = t && await store.getUser(t.u);
  if (!u || (u.pv || 1) !== t.pv) return res.status(401).json({ error: 'Sesi berakhir. Silakan masuk kembali.' });
  req.user = u; next();
});
const admin = (req, res, next) => req.user.role === 'Admin' ? next() : res.status(403).json({ error: 'Hanya pimpinan yang dapat melakukan ini.' });
// Perlindungan CSRF sederhana: request yang mengubah data wajib membawa header khusus.
app.use('/api', (req, res, next) => {
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method) && req.get('X-Requested-With') !== 'fetch')
    return res.status(400).json({ error: 'Permintaan tidak valid.' });
  next();
});

/* ---------- Pembatas percobaan login ---------- */
const tries = new Map();
const limited = ip => { const t = tries.get(ip); return t && t.n >= 10 && Date.now() - t.at < 15 * 6e4; };
const fail = ip => { const t = tries.get(ip); if (!t || Date.now() - t.at > 15 * 6e4) tries.set(ip, { n: 1, at: Date.now() }); else t.n++; };

/* ---------- API ---------- */
const json = express.json({ limit: '8mb' });

app.get('/api/health', (req, res) => res.json({ ok: true, store: store.kind.split(':')[0] }));

app.post('/api/login', json, wrap(async (req, res) => {
  const ip = req.ip;
  if (limited(ip)) return res.status(429).json({ error: 'Terlalu banyak percobaan. Coba lagi dalam 15 menit.' });
  const u = String(req.body?.u || '').trim().toLowerCase(), p = String(req.body?.p || '');
  const user = await store.getUser(u);
  if (!user || !(await checkPw(p, user.pass_hash))) { fail(ip); return res.status(401).json({ error: 'Username atau password salah.' }); }
  tries.delete(ip);
  setSid(req, res, makeToken(user), SESSION_DAYS * 86400);
  res.json({ user: pub(user) });
}));

app.post('/api/logout', (req, res) => { setSid(req, res, '', 0); res.json({ ok: true }); });

app.get('/api/session', auth, (req, res) => res.json({ user: pub(req.user) }));

app.get('/api/users', auth, wrap(async (req, res) => res.json(await store.listUsers())));

app.post('/api/users', auth, admin, json, wrap(async (req, res) => {
  const u = String(req.body?.u || '').trim().toLowerCase(), p = String(req.body?.p || ''),
    name = String(req.body?.name || '').trim().slice(0, 80) || u, role = req.body?.role;
  if (!validUser(u)) return res.status(400).json({ error: 'Username 3–32 karakter: huruf kecil, angka, titik, strip, atau garis bawah.' });
  if (p.length < 8) return res.status(400).json({ error: 'Password minimal 8 karakter.' });
  if (!ROLES.includes(role)) return res.status(400).json({ error: 'Role tidak valid.' });
  if (await store.getUser(u)) return res.status(409).json({ error: 'Username sudah dipakai.' });
  await store.createUser({ u, name, role, pass_hash: await hashPw(p) });
  res.json(await store.listUsers());
}));

app.delete('/api/users/:u', auth, admin, wrap(async (req, res) => {
  const u = req.params.u;
  if (u === req.user.u) return res.status(400).json({ error: 'Anda tidak dapat menghapus akun sendiri.' });
  const x = await store.getUser(u);
  if (!x) return res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
  if (x.role === 'Admin' && (await store.listUsers()).filter(y => y.role === 'Admin').length < 2)
    return res.status(400).json({ error: 'Minimal harus ada satu akun pimpinan.' });
  await store.deleteUser(u);
  res.json(await store.listUsers());
}));

app.post('/api/users/:u/password', auth, admin, json, wrap(async (req, res) => {
  const p = String(req.body?.p || '');
  if (p.length < 8) return res.status(400).json({ error: 'Password minimal 8 karakter.' });
  if (!(await store.getUser(req.params.u))) return res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
  await store.setPassword(req.params.u, await hashPw(p));
  res.json({ ok: true });
}));

app.post('/api/password', auth, json, wrap(async (req, res) => {
  const o = String(req.body?.old || ''), n = String(req.body?.new || '');
  if (!(await checkPw(o, req.user.pass_hash))) return res.status(400).json({ error: 'Password lama salah.' });
  if (n.length < 8) return res.status(400).json({ error: 'Password baru minimal 8 karakter.' });
  await store.setPassword(req.user.u, await hashPw(n));
  const u = await store.getUser(req.user.u);
  setSid(req, res, makeToken(u), SESSION_DAYS * 86400);
  res.json({ ok: true });
}));

const cleanState = d => {
  if (!d || typeof d !== 'object' || Array.isArray(d)) return null;
  const { users, me, ...rest } = d; // akun & sesi tidak pernah disimpan di dokumen data
  if (!Array.isArray(rest.reqs) || !Array.isArray(rest.notes) || !Array.isArray(rest.log) || !Number.isFinite(+rest.seq)) return null;
  rest.log = rest.log.slice(0, 5000);
  rest.notes = rest.notes.slice(0, 2000);
  return rest;
};

app.get('/api/state', auth, wrap(async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.query.v && +req.query.v === await store.getVersion()) return res.status(204).end();
  res.json(await store.getState());
}));

app.put('/api/state', auth, json, wrap(async (req, res) => {
  const data = cleanState(req.body?.data), base = +req.body?.version;
  if (!data || !Number.isFinite(base)) return res.status(400).json({ error: 'Data tidak valid.' });
  const v = await store.putState(data, base);
  if (v == null) return res.status(409).json(await store.getState());
  res.json({ version: v });
}));

app.post('/api/reset', auth, admin, wrap(async (req, res) => {
  await store.reset();
  res.json(await store.getState());
}));

app.post('/api/files', auth, express.raw({ type: () => true, limit: MAX_FILE }), wrap(async (req, res) => {
  const mime = String(req.get('Content-Type') || '').split(';')[0].trim().toLowerCase();
  const ext = MIME[mime];
  if (!ext) return res.status(415).json({ error: 'Jenis berkas tidak didukung.' });
  if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ error: 'Berkas kosong.' });
  let name = 'berkas.' + ext;
  try { name = decodeURIComponent(req.get('X-File-Name') || name).replace(/[\\/\r\n"]/g, '_').slice(0, 150); } catch (e) {}
  const id = crypto.randomBytes(16).toString('hex');
  await store.putFile({ id, name, mime, data: req.body, by: req.user.u });
  res.json({ url: `/api/files/${id}.${ext}`, name });
}));

app.get('/api/files/:f', auth, wrap(async (req, res) => {
  const id = String(req.params.f).split('.')[0];
  const f = /^[a-f0-9]{32}$/.test(id) && await store.getFile(id);
  if (!f) return res.status(404).send('Berkas tidak ditemukan');
  res.set({
    'Content-Type': f.mime,
    'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(f.name || id)}`,
    'Cache-Control': 'private, max-age=31536000, immutable',
  });
  res.send(Buffer.from(f.data));
}));

app.use('/api', (req, res) => res.status(404).json({ error: 'Tidak ditemukan.' }));

/* ---------- Frontend ---------- */
app.use(express.static(path.join(__dirname, 'public'), { maxAge: PROD ? '1h' : 0, index: 'index.html' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Ukuran data/berkas terlalu besar.' });
  console.error(err);
  res.status(500).json({ error: 'Terjadi kesalahan pada server.' });
});

/* ---------- Start ---------- */
async function seedUsers() {
  if (await store.countUsers()) return;
  const def = [
    { u: 'bendahara', name: 'Desta Amelia Sari', role: 'Bendahara', p: process.env.BENDAHARA_PASSWORD || 'bendahara123' },
    { u: 'pimpinan', name: 'Dini Eka Prasasti', role: 'Admin', p: process.env.PIMPINAN_PASSWORD || 'pimpinan123' },
  ];
  for (const d of def) await store.createUser({ u: d.u, name: d.name, role: d.role, pass_hash: await hashPw(d.p) });
  console.log('Akun awal dibuat: bendahara, pimpinan. Segera ganti password setelah login pertama.');
}
async function cleanup() {
  try {
    const s = JSON.stringify((await store.getState()).data);
    const keep = new Set([...s.matchAll(/\/api\/files\/([a-f0-9]{32})/g)].map(m => m[1]));
    const n = await store.cleanupFiles(keep);
    if (n) console.log(`Membersihkan ${n} berkas yang tidak dipakai.`);
  } catch (e) { console.error('cleanup', e.message); }
}

(async () => {
  await store.init();
  await seedUsers();
  cleanup(); setInterval(cleanup, 6 * 3600e3).unref();
  app.listen(PORT, () => console.log(`Server berjalan di port ${PORT} (penyimpanan: ${store.kind})`));
})().catch(e => { console.error('Gagal memulai server:', e); process.exit(1); });
